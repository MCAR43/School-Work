#include <iostream>
int main(){
  std::cout << "352" << std::endl;
  return 0;
}
