#include <iostream>
int main(){
  std::cout << "252" << std::endl;
  return 0;
}
