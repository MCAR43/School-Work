## MFPL-Intepreter
An interpreter built on bison, and flex to perform lexical and semantic analysis for the MFPL programming language

## How To Run
```
 * make
 * ./testScript.sh
```
### Requires
```
Bison 2.3
Flex 2.5.35
```

## Authors
#### Pair-Programmed by:
* **Mark Anderson**
* **Tanner Wendland**

